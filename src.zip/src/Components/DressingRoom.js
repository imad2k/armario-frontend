import React from 'react'

export default function DressingRoom() {
    return (
        <div>
            <h1>This is the dressing room page</h1>
        </div>
    )
}
