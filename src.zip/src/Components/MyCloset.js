import React from 'react'

export default function MyCloset() {
    return (
        <div>
            <h1>This is the my closet page</h1>
        </div>
    )
}
